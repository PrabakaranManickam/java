package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class SearchEmployee1 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchEmployee1 frame = new SearchEmployee1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchEmployee1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSearchAndUpdate = new JLabel("Search and Update employee details");
		lblSearchAndUpdate.setBounds(134, 11, 252, 23);
		contentPane.add(lblSearchAndUpdate);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setBounds(40, 50, 90, 23);
		contentPane.add(lblFirstName);
		
		textField = new JTextField();
		textField.setBounds(156, 50, 142, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		final JButton btnViewDetails = new JButton("View Details");
		btnViewDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
								{
								String u=textField.getText();
									String qstr1="select faname,mnumber,email from emp where fname='"+u+"'";
									System.out.println("DB============>");
									Class.forName("org.h2.Driver");
									Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
									System.out.println("DB============7777>");
									Statement stm=conn.createStatement();
									ResultSet rs=stm.executeQuery(qstr1);
									rs.next();
									System.out.println("DB============sest text>");
									textField_1.setText(rs.getString(1).trim());
								int mobileno=rs.getInt(2);
								textField_2.setText(String.valueOf(mobileno));
									textField_3.setText(rs.getString(3).trim());
									
									
									
									JOptionPane.showMessageDialog(btnViewDetails, "SearchSucess!!");
								}
								catch(Exception t)
								{
									
								}
				
			}
		});
		btnViewDetails.setBounds(310, 50, 114, 23);
		contentPane.add(btnViewDetails);
		
		final JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					String u=textField.getText();
					String sfaname=textField_1.getText();
				    int imobileno=Integer.parseInt(textField_2.getText());
				    String semail = textField_3.getText();
					String str="update emp set faname='"+sfaname+"',email='"+semail+"',mnumber= '"+imobileno+"' where fname='"+u+"'";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					Statement stm=conn.createStatement();
					stm.executeUpdate(str);
					System.out.println("UP=====99999");
					JOptionPane.showMessageDialog(btnUpdate, "UpdatedSucess!!");
					
					
				}
				catch(Exception t)
				{
					JOptionPane.showMessageDialog(btnUpdate, "employee not found!!");
				}

			}
		});
		btnUpdate.setBounds(238, 228, 89, 23);
		contentPane.add(btnUpdate);
		
		JLabel lblFathersName = new JLabel("Fathers Name");
		lblFathersName.setBounds(40, 83, 90, 22);
		contentPane.add(lblFathersName);
		
		JLabel lblEmail = new JLabel("Mobile No");
		lblEmail.setBounds(40, 133, 90, 14);
		contentPane.add(lblEmail);
		
		JLabel lblMobileno = new JLabel("Email");
		lblMobileno.setBounds(40, 168, 62, 14);
		contentPane.add(lblMobileno);
		
		textField_1 = new JTextField();
		textField_1.setBounds(156, 83, 142, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(156, 129, 142, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(156, 164, 142, 23);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
	}
}
