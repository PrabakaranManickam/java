package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class welcomepage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcomepage frame = new welcomepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public welcomepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 457, 323);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcomeToHr = new JLabel("Welcome  To HR Management Systems");
		lblWelcomeToHr.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblWelcomeToHr.setBounds(92, 26, 297, 14);
		contentPane.add(lblWelcomeToHr);
		
		textField = new JTextField();
		textField.setBounds(117, 125, 99, -8);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Registration");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new RegisterPage().setVisible(true);
			}
		});
		btnNewButton.setBounds(161, 118, 136, 23);
		contentPane.add(btnNewButton);
		
		JButton btnEmployeeDetails = new JButton("Employee Details");
		btnEmployeeDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AdminViewPage().setVisible(true);
			}
		});
		btnEmployeeDetails.setBounds(161, 73, 136, 23);
		contentPane.add(btnEmployeeDetails);
		
		JButton btnNewButton_1 = new JButton("SearchEmployee");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new SearchEmployee1().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(161, 164, 136, 23);
		contentPane.add(btnNewButton_1);
	}
}
