package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class AdminViewPage extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminViewPage frame = new AdminViewPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminViewPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnEmployeedetails = new JButton("EmployeeDetails");
		btnEmployeedetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					String qstr="select * from emp";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					Statement stm=conn.createStatement();
					
					ResultSet rs=stm.executeQuery(qstr);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				}
				catch(Exception t)
				{
					System.out.println(t);
				}

			}
		});
		btnEmployeedetails.setBounds(143, 23, 178, 23);
		contentPane.add(btnEmployeedetails);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 57, 414, 193);
		contentPane.add(panel);
		
		table = new JTable();
		panel.add(table);
		
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane);
	}
}
