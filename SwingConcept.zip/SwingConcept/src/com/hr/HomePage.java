package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class HomePage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage frame = new HomePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Employer Log in");
		lblNewLabel.setBounds(185, 59, 120, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblUsername = new JLabel("UserName:");
		lblUsername.setBounds(111, 84, 80, 14);
		contentPane.add(lblUsername);
		
		textField = new JTextField();
		textField.setBounds(185, 81, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(112, 122, 63, 14);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(185, 119, 86, 20);
		contentPane.add(passwordField);
		
		final JButton btnLogIn = new JButton("Log in");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try
				{
					String u=textField.getText();
					String p=passwordField.getText();
							String str="select * from hrlogin where uname='"+u+"'";
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					Connection conn=DriverManager.getConnection("jdbc:odbc:alogin","","");
					Statement stmt=conn.createStatement();
					ResultSet rs=stmt.executeQuery(str);
					rs.next();
					String auname=rs.getString(1);
					String pass=rs.getString(2);
					if(u.equals(auname)&&p.equals(pass))
					{
						JOptionPane.showMessageDialog(btnLogIn, "LoginSucss");;
						new welcomepage().setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(btnLogIn, "LoginFaile");
					}
					
				}
				catch(Exception t)
				{
					JOptionPane.showMessageDialog(btnLogIn, "LoginFail");
				}
				
				
			}
		});
		btnLogIn.setBounds(183, 163, 102, 23);
		contentPane.add(btnLogIn);
		
		JLabel lblHrManagementSystem = new JLabel("HR Management System");
		lblHrManagementSystem.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHrManagementSystem.setBounds(155, 34, 194, 14);
		contentPane.add(lblHrManagementSystem);
	}
}
