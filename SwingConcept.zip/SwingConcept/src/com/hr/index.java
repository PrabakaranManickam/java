package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class index extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					index frame = new index();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public index() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcomeToHr = new JLabel("Welcome to HR Management System");
		lblWelcomeToHr.setBounds(113, 39, 273, 22);
		contentPane.add(lblWelcomeToHr);
		
		JButton btnEmployerLogin = new JButton("Employer");
		btnEmployerLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new HomePage().setVisible(true);
			}
		});
		btnEmployerLogin.setBounds(154, 85, 116, 23);
		contentPane.add(btnEmployerLogin);
		
		JButton btnEmployeeLogin = new JButton("Employee");
		btnEmployeeLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new UserHomePage().setVisible(true);
			}
		});
		btnEmployeeLogin.setBounds(154, 136, 116, 23);
		contentPane.add(btnEmployeeLogin);
	}
}
