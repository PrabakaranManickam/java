package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class EmployeeDetails extends JFrame {

	private JPanel contentPane;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_2;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeDetails frame = new EmployeeDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcomeToEmployee = new JLabel("Employee Details");
		lblWelcomeToEmployee.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblWelcomeToEmployee.setBounds(146, 11, 183, 21);
		contentPane.add(lblWelcomeToEmployee);
		
		JLabel lblFirstName = new JLabel(" Name");
		lblFirstName.setBounds(28, 36, 63, 21);
		contentPane.add(lblFirstName);
		
		JLabel lblEmpId = new JLabel("Emp ID");
		lblEmpId.setBounds(28, 69, 46, 14);
		contentPane.add(lblEmpId);
		
		JLabel lblBloodGroup = new JLabel("Blood Group");
		lblBloodGroup.setBounds(28, 96, 79, 15);
		contentPane.add(lblBloodGroup);
		
		JLabel lblNationality = new JLabel("Nationality");
		lblNationality.setBounds(28, 122, 63, 19);
		contentPane.add(lblNationality);
		
		JLabel lblCity = new JLabel("City");
		lblCity.setBounds(28, 152, 46, 15);
		contentPane.add(lblCity);
		
		JLabel lblPincode = new JLabel("Pincode");
		lblPincode.setBounds(28, 178, 46, 14);
		contentPane.add(lblPincode);
		
		JLabel lblPhone = new JLabel("Phone No");
		lblPhone.setBounds(28, 203, 79, 14);
		contentPane.add(lblPhone);
		
		textField_5 = new JTextField();
		textField_5.setBounds(243, 200, 86, 20);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(243, 175, 86, 20);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(243, 36, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(243, 66, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(243, 149, 86, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(243, 231, 89, 23);
		contentPane.add(btnCancel);
		
		textField_2 = new JTextField();
		textField_2.setBounds(243, 93, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(243, 121, 86, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
	}
}
