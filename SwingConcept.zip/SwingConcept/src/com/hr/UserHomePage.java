package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class UserHomePage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserHomePage frame = new UserHomePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserHomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcomeToHr = new JLabel("Welcome to HR Management System");
		lblWelcomeToHr.setBounds(140, 11, 246, 14);
		contentPane.add(lblWelcomeToHr);
		
		JLabel lblUserLogIn = new JLabel("Employee Log in");
		lblUserLogIn.setBounds(164, 36, 135, 14);
		contentPane.add(lblUserLogIn);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(81, 77, 77, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(81, 120, 77, 14);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(164, 74, 135, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(164, 117, 135, 20);
		contentPane.add(passwordField);
		
		final JButton btnLogIn = new JButton("Log in");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					String u=textField.getText();
					String p=passwordField.getText();
							String str="select * from user_login where ulogin='"+u+"'";
							Class.forName("org.h2.Driver");
							Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					Statement stmt=conn.createStatement();
					ResultSet rs=stmt.executeQuery(str);
					rs.next();
					String auname=rs.getString(1);
					String pass=rs.getString(2);
					if(u.equals(auname)&&p.equals(pass))
					{
						JOptionPane.showMessageDialog(btnLogIn, "LoginSuccess");;
						new UserPage().setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(btnLogIn, "LoginFail");
					}
					
				}
				catch(Exception t)
				{
					JOptionPane.showMessageDialog(btnLogIn, "LoginFail");
				}
				
				
			}
		});
		btnLogIn.setBounds(161, 190, 138, 23);
		contentPane.add(btnLogIn);
	}
}
