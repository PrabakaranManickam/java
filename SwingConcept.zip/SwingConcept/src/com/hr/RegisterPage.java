package com.hr;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;

public class RegisterPage extends JFrame {

	private JPanel contentPane;
	private JTextField tFirstName;
	private JTextField tFather;
	private JTextField tMother;
	private JTextField tContactno;
	private JTextField tEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterPage frame = new RegisterPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewRegistration = new JLabel("New Registration");
		lblNewRegistration.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewRegistration.setBounds(128, 0, 162, 22);
		contentPane.add(lblNewRegistration);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setBounds(10, 40, 129, 14);
		contentPane.add(lblFirstName);
		
		tFirstName = new JTextField();
		tFirstName.setBounds(128, 40, 86, 14);
		contentPane.add(tFirstName);
		tFirstName.setColumns(10);
		
		
			
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(10, 90, 46, 14);
		contentPane.add(lblGender);
		
		JLabel lblNationality = new JLabel("Nationality");
		lblNationality.setBounds(10, 115, 86, 14);
		contentPane.add(lblNationality);
		
		JLabel lblFathersName = new JLabel("Father's Name");
		lblFathersName.setBounds(10, 140, 96, 14);
		contentPane.add(lblFathersName);
		
		tFather = new JTextField();
		tFather.setBounds(128, 140, 86, 14);
		contentPane.add(tFather);
		tFather.setColumns(10);
		
		JLabel lblMothersName = new JLabel("Mother's Name");
		lblMothersName.setBounds(10, 165, 107, 14);
		contentPane.add(lblMothersName);
		
		tMother = new JTextField();
		tMother.setBounds(128, 165, 86, 14);
		contentPane.add(tMother);
		tMother.setColumns(10);
		
		JLabel lblContactNo = new JLabel("Contact No");
		lblContactNo.setBounds(10, 190, 96, 14);
		contentPane.add(lblContactNo);
		
		tContactno = new JTextField();
		tContactno.setBounds(183, 193, 86, 14);
		contentPane.add(tContactno);
		tContactno.setColumns(10);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setBounds(10, 215, 86, 14);
		contentPane.add(lblEmail);
		
		tEmail = new JTextField();
		tEmail.setBounds(128, 215, 174, 14);
		contentPane.add(tEmail);
		tEmail.setColumns(10);
		
		JLabel lblPersonalDetails = new JLabel("Personal Details");
		lblPersonalDetails.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPersonalDetails.setForeground(Color.BLUE);
		lblPersonalDetails.setBackground(Color.BLUE);
		lblPersonalDetails.setBounds(10, 15, 118, 14);
		contentPane.add(lblPersonalDetails);
		
		
		final JRadioButton rdbtnMale = new JRadioButton("Male");
		rdbtnMale.setBounds(128, 86, 76, 23);
		contentPane.add(rdbtnMale);
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setBounds(224, 86, 109, 23);
		contentPane.add(rdbtnFemale);
		
		ButtonGroup gender=new ButtonGroup();
		gender.add(rdbtnMale);
		gender.add(rdbtnFemale);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"+91", "+92", "+93", "+94"}));
		comboBox_1.setBounds(128, 190, 46, 20);
		contentPane.add(comboBox_1);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Indian", "Others"}));
		comboBox.setBounds(128, 112, 76, 20);
		contentPane.add(comboBox);
		
		final JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					String firstname=tFirstName.getText();
					String fathername=tFather.getText();
					String mothername=tMother.getText();
					String gen="";
					String nationality=(String) comboBox.getSelectedItem();
					
					if(rdbtnMale.isSelected())
					{
					  gen="Male";
					}
					else
					{
						gen="Female";
					}
					int iMobile= Integer.parseInt(tContactno.getText());
					String sEmail=tEmail.getText();
					
					 String qstr="insert into emp values(?,?,?,?,?,?,?)";
					//String qstr1="insert into ureg values('"+u+"','"+gen+"','"+cource+"','"+ug+"','"+pg+"')";
					Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
					//Statement stm=conn.createStatement();
					//stm.executeUpdate(qstr1);
					PreparedStatement pt=conn.prepareStatement(qstr);
					pt.setString(1,firstname);
					pt.setString(2,fathername );
					pt.setString(3,mothername);
					pt.setString(4,gen);
					pt.setString(5,nationality);
					pt.setInt(6,iMobile);
					pt.setString(7,sEmail);
					pt.executeUpdate();
					JOptionPane.showMessageDialog(btnSave, "Inserted..");
				}
				catch(Exception t)
				{
					System.out.println(t);
				}

				
				
			}
		});
		btnSave.setBounds(128, 240, 89, 22);
		contentPane.add(btnSave);
		

		
	}
}
